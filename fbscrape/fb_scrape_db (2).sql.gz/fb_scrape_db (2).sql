-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 14, 2020 lúc 05:19 PM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `fb_scrape_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `demo1`
--

CREATE TABLE `demo1` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_09_07_043550_create_tbl_job_hirring', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_brand_product`
--

CREATE TABLE `tbl_brand_product` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_brand_product`
--

INSERT INTO `tbl_brand_product` (`brand_id`, `brand_name`, `brand_desc`, `brand_status`) VALUES
(1, 'test', NULL, 1),
(2, 'test2', NULL, 1),
(3, 'test3', 'day la mo ta ne ', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_chat`
--

CREATE TABLE `tbl_chat` (
  `id` int(11) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_chat`
--

INSERT INTO `tbl_chat` (`id`, `content`, `time`) VALUES
(28, 'helu', '2020-10-09 14:51:31'),
(29, 'kkkkkkkkk', '2020-10-09 14:51:52'),
(30, 'ijiokokokoko', '2020-10-09 14:51:57'),
(31, 'yyyyyyygyybjnjnj', '2020-10-09 14:55:28'),
(32, 'iiiiiii', '2020-10-09 14:55:34'),
(33, '2123212313', '2020-10-09 14:57:59'),
(34, '2121212121212121', '2020-10-09 14:58:05'),
(35, 'le trung hieu\r\nkakakak', '2020-10-09 14:58:14'),
(36, 'ssssdsdsdsdsdsd', '2020-10-09 15:06:53'),
(37, 'ssss', '2020-10-09 15:06:56'),
(38, 'sdsd', '2020-10-09 15:06:57'),
(39, 'ssaaaaaaa', '2020-10-09 15:07:05'),
(40, 'khoong saoo dau', '2020-10-09 15:08:31'),
(41, 'cái gì vậy', '2020-10-09 15:08:57'),
(42, 'lê trung hiếu', '2020-10-09 15:09:13'),
(43, 'llll', '2020-10-09 15:11:24'),
(44, 'đại học duy tân', '2020-10-09 15:13:42'),
(45, 'đại học duy tân', '2020-10-09 15:14:19'),
(46, 'đại học duy tân', '2020-10-09 15:15:17'),
(47, 'đại học duy tân', '2020-10-09 15:15:26'),
(48, 'đại học duy tân', '2020-10-09 15:15:34'),
(49, 'đại học duy tân', '2020-10-09 15:16:06'),
(50, 'sss', '2020-10-09 15:22:15'),
(51, 'sssaaaaa', '2020-10-09 15:27:16'),
(52, 'hahahah', '2020-10-09 15:27:59'),
(53, 'ooo', '2020-10-09 15:29:23'),
(54, 'ô', '2020-10-09 15:29:26'),
(55, 'sss', '2020-10-10 03:58:54'),
(56, 'aaaaasdsd', '2020-10-11 07:43:29');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `id_topic` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `daytime_cmt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_comments`
--

INSERT INTO `tbl_comments` (`id`, `id_topic`, `id_user`, `comment`, `daytime_cmt`) VALUES
(4, 10, 10, 'mua pc đi', '2020-10-12 15:05:51'),
(8, 56, 9, 'Nếu dùng laravel thì nên vue', '2020-10-14 00:24:20'),
(9, 56, 10, 'Vuejs hình như dễ hơn á', '2020-10-14 00:25:18');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_job_hirring`
--

CREATE TABLE `tbl_job_hirring` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_mail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `programing_language` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_position` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_post` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_job_hirring`
--

INSERT INTO `tbl_job_hirring` (`id`, `company_name`, `company_mail`, `programing_language`, `job_position`, `link_post`, `post_desc`, `status`, `created_at`) VALUES
(184, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-09-30 16:07:52'),
(185, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-09-30 16:07:53'),
(186, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-09-30 16:07:53'),
(187, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, C++', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-09-30 16:09:23'),
(189, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-09-30 16:09:23'),
(191, 'enjoyworks', 'enjoy-danang@enjoyworks.co', 'Java, PHP, Python', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768784699955168/', 'Bạn có mún Works From Home trong mùa Covid??? Hãy đến ngay Enjoyworks nhà mình nhé. List HOT JOB cho các dev thời cô vi đây ạ!!! SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM ( (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Công ty đang làm nhiều dự án lớn, khách hàng lớn, ổn định với các đối tác Hàn Quốc như:  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính ) Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) Và còn nhiều dự án lớn khác....  Lương các dev sẽ được deal thõa mãn tùy năng lực của mình cộng với lương 13, review lương hằng năm đầy đủ, Happy Hour, sinh nhật đầy đủ không thiếu... Nhanh tay gởi CV qua mail: enjoy-danang@enjoyworks.co', 0, '2020-09-30 16:09:23'),
(236, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-02 03:27:17'),
(237, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-02 03:27:17'),
(238, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-02 03:27:17'),
(241, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-02 03:27:17'),
(243, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-02 03:27:18'),
(244, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-02 05:56:33'),
(245, 'Pure-electric', 'info@pure-electric.com.au', 'JavaScript', '', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', 'Pure Electric Solutions đang cần tuyển 1 React JS Developer ạ Saly: $1000 - $1600 >2 năm kinh nghiệm với JavaScript, familiar với React, ES6Làm việc trực tiếp với người Úc và team Việt Nam - Hỗ trợ đào tạo tiếng anh để trở thành công dân toàn cầuLocation: Cẩm Lệ,Nẵng Contact: info@pure-electric.com.au Ib mình để nhận JD chi tiết nhé:))', 0, '2020-10-02 06:02:09'),
(246, 'Pure-electric', 'info@pure-electric.com.au', 'JavaScript', '', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', 'Pure Electric Solutions đang cần tuyển 1 React JS Developer ạ Saly: $1000 - $1600 >2 năm kinh nghiệm với JavaScript, familiar với React, ES6Làm việc trực tiếp với người Úc và team Việt Nam - Hỗ trợ đào tạo tiếng anh để trở thành công dân toàn cầuLocation: Cẩm Lệ,Nẵng Contact: info@pure-electric.com.au Ib mình để nhận JD chi tiết nhé:))', 0, '2020-10-02 06:02:54'),
(247, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-02 06:12:05'),
(248, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-02 06:12:05'),
(249, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-02 06:12:05'),
(251, 'enjoyworks', 'enjoy-danang@enjoyworks.co', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768784699955168/', 'Bạn có mún Works From Home trong mùa Covid??? Hãy đến ngay Enjoyworks nhà mình nhé. List HOT JOB cho các dev thời cô vi đây ạ!!! SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM ( (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Công ty đang làm nhiều dự án lớn, khách hàng lớn, ổn định với các đối tác Hàn Quốc như:  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính ) Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) Và còn nhiều dự án lớn khác....  Lương các dev sẽ được deal thõa mãn tùy năng lực của mình cộng với lương 13, review lương hằng năm đầy đủ, Happy Hour, sinh nhật đầy đủ không thiếu... Nhanh tay gởi CV qua mail: enjoy-danang@enjoyworks.co', 0, '2020-10-02 06:12:05'),
(252, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-02 06:12:05'),
(253, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-02 06:12:05'),
(254, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-02 06:12:05'),
(255, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-02 07:44:50'),
(259, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:28:48'),
(260, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:28:48'),
(261, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:28:48'),
(263, 'enjoyworks', 'enjoy-danang@enjoyworks.co', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768784699955168/', 'Bạn có mún Works From Home trong mùa Covid??? Hãy đến ngay Enjoyworks nhà mình nhé. List HOT JOB cho các dev thời cô vi đây ạ!!! SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM ( (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Công ty đang làm nhiều dự án lớn, khách hàng lớn, ổn định với các đối tác Hàn Quốc như:  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính ) Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) Và còn nhiều dự án lớn khác....  Lương các dev sẽ được deal thõa mãn tùy năng lực của mình cộng với lương 13, review lương hằng năm đầy đủ, Happy Hour, sinh nhật đầy đủ không thiếu... Nhanh tay gởi CV qua mail: enjoy-danang@enjoyworks.co', 0, '2020-10-03 06:28:48'),
(264, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:28:49'),
(265, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:28:49'),
(266, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:28:49'),
(267, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:33:36'),
(268, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:33:36'),
(269, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:33:37'),
(272, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:33:37'),
(273, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:33:37'),
(274, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:33:37'),
(275, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:38:16'),
(276, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:38:16'),
(277, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:38:16'),
(280, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:38:16'),
(281, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:38:16'),
(282, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:38:16'),
(283, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:45:12'),
(284, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:45:12'),
(285, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:45:12'),
(288, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:45:12'),
(289, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:45:13'),
(290, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:45:13'),
(291, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:48:13');
INSERT INTO `tbl_job_hirring` (`id`, `company_name`, `company_mail`, `programing_language`, `job_position`, `link_post`, `post_desc`, `status`, `created_at`) VALUES
(292, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:48:13'),
(293, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:48:13'),
(296, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:48:14'),
(297, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:48:14'),
(298, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:48:14'),
(299, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:48:44'),
(300, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:48:44'),
(301, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:48:44'),
(304, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:48:44'),
(305, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:48:44'),
(306, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:48:45'),
(307, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:48:45'),
(308, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:48:45'),
(309, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:48:45'),
(312, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:48:45'),
(313, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:48:45'),
(314, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:48:45'),
(339, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 06:58:05'),
(340, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 06:58:05'),
(341, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 06:58:05'),
(344, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 06:58:06'),
(345, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 06:58:06'),
(346, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 06:58:06'),
(347, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 09:29:17'),
(348, 'Trong', 'hr@dactech.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768884789945159/', 'Những chiếc job #PHP #Java #QC sang xịn mịn của nhà #DACTechViệtNam vẫn đang chờ các vị huynh đài đến hốt  lia lịa đây ạ PHỎNG VẤN ONLINE>>> ON-BOARD TẠI GIA LIỀN NGAY VÀ LẬP TỨC JD CÁC VỊ TRÍ:QC: https://bit.ly/329PNJfPHP: http://bit.ly/2kUsRKGJAVA: http://bit.ly/33MI4OzQUYỀN LỢI:Mức lương: lên tới 1000$Review lương hàng nămBonus: 02 lần/năm (Bonus Mùa hè & Bonus Tết)100% lương trong thời gian thử việcQuà tặng vào mỗi dịp lễ (01/05, 02/09, Tết Dương lịch)Bảo hiểm xã hội theo luật Lao động và Bảo hiểm cao cấp Tokio MarineTiệc Happy Hour hàng tuần, Team Building hàng tháng, Kick-off hàng quý, Company Trip hàng nămLớp học tiếng Nhật miễn phí (học tại công ty trong thời gian làm việc)Trợ cấp chức vụ, nhà ở, đi lại, ăn trưaTrợ cấp đối với chứng chỉ tiếng Nhật (lên đến 8 triệu/tháng) & và các chứng chỉ kỹ thuật (Java, Ruby, Software Tester, Scrum Master, …)Chế độ chăm sóc phụ nữ: Nghỉ sinh lý phụ nữ: 01 ngày/tháng; nghỉ sau sinh cho nhân viên nữ có con dưới 01 tuổi: 01h/ngàyLIÊN HỆ: Email: hr@dactech.vn Skype: jujuphan (Ms. Trinh Phan) hoặc live:e49e5c5d4eeec867 (Ms. Tú) Địa chỉ: tầng 06, Tòa nhà VNPT, Đường 344 2/9, Quận Hải Châu, Đà Nẵng Giờ làm việc: 8h - 17h (thứ 2 - thứ 6)', 0, '2020-10-03 09:29:17'),
(349, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 09:29:17'),
(352, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 09:29:17'),
(353, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 09:29:18'),
(354, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 09:29:18'),
(355, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-03 09:29:20'),
(357, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-03 09:29:20'),
(360, 'Rikkeisoft', 'hott@rikkeisoft.comSkype:', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768728899960748/', 'Thả nhẹ cái JOB đầu tuần, cuối tháng.Muôn vàn cơ hội vi vu Nhật tại Rikkei :)Sinh viên năm 3, năm 4, tiếng Nhật ~N3, ký naitei, bay sang Nhật vào tháng 10/2021BrSE > 1 năm kinh nghiệm, tiếng Nhật ~N2, giao tiếp ổn, nếu có nguyện vọng onsite có thể sắp xếp tháng 10.Inbox để trao đổi thông tin chi tiết:Mail: hott@rikkeisoft.comSkype: hotran.cfl', 0, '2020-10-03 09:29:20'),
(361, 'Nfq', 'career@nfq.asia', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', 'From 0 to more than 40 people , we are now happy to share that  our 2nd Office in Danang is coming soon  and welcoming more talented engineers to help us rock many upcoming challenging projects!\n - PHP Engineers (Middle to Senior Level):  https://www.nfq.asia/job/php-developer - FE Engineers (Middle to Senior Level): https://www.nfq.asia/job/front-end-developer - Technical Leader: https://www.nfq.asia/job/technical-lead-php-js-e-commerce - Ruby on Rails Engineers (Senior Level): https://www.nfq.asia/job/senior-ruby-on-rails-developer\n  More detail of the 2nd office will be published soon!   If you want to drop by, don’t hesitate to contact us and we\'ll send you an invitation.  If you want to discover as an insider, send us your CV to career@nfq.asia\n #NFQAsia #2ndOfficeinDanang #Hiring #PHP #FE #TechLead #RoR', 0, '2020-10-03 09:29:20'),
(362, 'Enjoyworks', 'enjoy-danang@enjoyworks.co.kr', 'Java, PHP, Ruby', 'Dev, Senior', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768677766632528/', '[ĐN] Cảm lạnh có thể là do gió. Nhưng cảm nắng chắc chắn là do job xịn ở Enjoyworks nhà em. Offer cực đã, hốt ngay kẻo lỡ nhé Dev ơi.  SENIOR JAVA (Có kinh nghiệm về thiết kế, phát triễn ứng dụng Java, biết về công nghệ My SQL, ORM  (JPA2, Hibernate)) ...  SENIOR PHP ( có kn về PHP (Laravel), biết ReactJS là 1 lợi thế)  SENIOR TESTER ( có kn về test plan, test cases, test scenarios, test UIs, function/non-function, APIs, front-end systems is plus...)  SENIOR REACTJS ( (biết reactjs, redux, react-hooks) biết react native là lợi thế, có kn về html5,css3) Dự án lớn, về đều đều, đang chờ các bác về với Enjoyworks nhà em  Dự ánTrading System Project (hệ thống giao dịch Kamex)  Dự án AI ứng dụng làm việc qua video call ( áp dụng cho các trung tâm hành chính )  Dự án giáo dục thông qua các K-pop Star (học tiếng hàn thông qua các video của các ngôi sao Hàn Quốc ) WFH mùa covid, lương đánh giá theo năng lực, lương 13, review hằng năm, sinh nhật, Happy Hour không thiếu, mỗi tháng được hỗ trợ kinh phí nhậu nhẹt thả ga...... Apply qua mail: enjoy-danang@enjoyworks.co.kr', 0, '2020-10-03 09:29:20'),
(366, 'Outsource', 'jessie.tran0508@gmail.com', 'Java, PHP', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768931823273789/', '[HCM/ĐÀ NẴNG] SENIOR BACKEND (JAVA/PHP/GOLANG/KOTLIN) - MAX 2500$ GROSS - 3 NĂM KINH NGHIỆM - CÔNG TY OUTSOURCE SWEDEN - TIẾNG ANH GIAO TIẾP Chính sách work from home 9 ngày/ 1 tháng + SHARES/STOCKS Cơ hội onsite ở clients ở EU Mình cần tìm dev backend 1 trong các ngôn ngữ ở trên để xây dựng microservice system cho client ở Đức Yêu cầu công việc: • At least 3-year experience in web application development • Experience in any programming languages, prefers Java/Kotlin, Golang, PHP • Experienced with REST API, Service Oriented Architecture •Good knowledge of OOP, software design (clean code, design patterns, SOLID,…) • Experience with MySQL and PostgreSQL Database •Good English skills, especially speaking and writing\n •Experience in Devops/ AWS (plus, but not mandatory)\n BENEFIT · Thưởng tháng 13 · Xét tăng lương 1 năm 2 lần - Khám sức khoẻ định kỳ hàng năm - Được đóng BHXH, BHYT đầy đủ. Các bạn quan tâm vui lòng INBOX hoặc Skyp: hoaigiang.tran0404 Mail: jessie.tran0508@gmail.com Em cám ơn ạ', 0, '2020-10-07 06:04:02'),
(368, 'Fsoft', 'SaTTL@fsoft.com.vn', 'Java, PHP, Ruby', 'Dev', 'https://www.facebook.com/groups/vieclamCNTTDaNang/permalink/1768865373280434/', 'Fsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438\nFsoft đang tuyển 30 Java kinh nghiệm 6 tháng trở lên cho tháng 9, tháng 10 nè cả nhà mình ơi  Onboard trong tháng 9 nhận signing bounus thêm 5-15M nè Hỗ trợ PV skype online, có kết quả trong ngày  Hỗ trợ process làm work from home trong thời gian giãn cách do Covid nè Các anh chị apply qua  Email: SaTTL@fsoft.com.vn Phone/Zalo/Skype: 0962622438', 0, '2020-10-07 06:04:03');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_likes`
--

CREATE TABLE `tbl_likes` (
  `id` int(11) NOT NULL,
  `id_topic` int(11) NOT NULL,
  `id_liker` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_likes`
--

INSERT INTO `tbl_likes` (`id`, `id_topic`, `id_liker`) VALUES
(33, 10, 9),
(44, 5, 10),
(48, 10, 10),
(52, 5, 1),
(93, 5, 9),
(117, 10, 1),
(124, 67, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_topic`
--

CREATE TABLE `tbl_topic` (
  `id` int(11) NOT NULL,
  `id_user_creator` int(11) NOT NULL,
  `title_topic` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_topic` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `favourite` int(11) NOT NULL DEFAULT 0,
  `daytime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_topic`
--

INSERT INTO `tbl_topic` (`id`, `id_user_creator`, `title_topic`, `content_topic`, `favourite`, `daytime`) VALUES
(5, 10, 'Máy ảnh , nhiếp ảnh , nên mua hãng nào ?', 'Máy ảnh crop censor quay phim tốt hơn hay máy ảnh full frame quay tốt hơn ?', 0, '2020-10-10 07:11:20'),
(10, 10, 'Góc tư vấn ..', 'Nên mua laptop nào để học đồ họa ?', 0, '2020-10-10 07:44:07'),
(56, 1, 'Nên học React hay Vuejs ?', 'ae vote nhé 1 hay 2  ..', 0, '2020-10-13 16:33:44'),
(66, 9, 'Có ai muốn học lập trình python không nhỉ ?', 'tặng miễn phí cho ai hứng thú', 0, '2020-10-14 06:56:55'),
(67, 9, 'Đang cần thay màn hình laptop Dell k nhờ ae ưi ?', 'ai biết ở đâu rẻ k', 0, '2020-10-14 06:59:15');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `test_diagram`
--

CREATE TABLE `test_diagram` (
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `test_diagram`
--

INSERT INTO `test_diagram` (`id`, `quantity`, `year`) VALUES
(1, 150, 2018),
(2, 300, 2019),
(3, 130, 2020);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `isAdmin` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `isAdmin`) VALUES
(1, 'le trung hieu', 'admin', NULL, '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, 1),
(9, 'Le Duc Tai', 'user', NULL, 'ee11cbb19052e40b07aac0ca060c23ee', NULL, NULL, NULL, 0),
(10, 'Phan Ngoc Anh', 'user2', NULL, '7e58d63b60197ceb55a1c487989a3720', NULL, NULL, NULL, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `demo1`
--
ALTER TABLE `demo1`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Chỉ mục cho bảng `tbl_brand_product`
--
ALTER TABLE `tbl_brand_product`
  ADD PRIMARY KEY (`brand_id`);

--
-- Chỉ mục cho bảng `tbl_chat`
--
ALTER TABLE `tbl_chat`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_comments_ibfk_1` (`id_topic`);

--
-- Chỉ mục cho bảng `tbl_job_hirring`
--
ALTER TABLE `tbl_job_hirring`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tbl_likes`
--
ALTER TABLE `tbl_likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_likes_ibfk_1` (`id_topic`);

--
-- Chỉ mục cho bảng `tbl_topic`
--
ALTER TABLE `tbl_topic`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `test_diagram`
--
ALTER TABLE `test_diagram`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `demo1`
--
ALTER TABLE `demo1`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `tbl_brand_product`
--
ALTER TABLE `tbl_brand_product`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `tbl_chat`
--
ALTER TABLE `tbl_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT cho bảng `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `tbl_job_hirring`
--
ALTER TABLE `tbl_job_hirring`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=382;

--
-- AUTO_INCREMENT cho bảng `tbl_likes`
--
ALTER TABLE `tbl_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT cho bảng `tbl_topic`
--
ALTER TABLE `tbl_topic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT cho bảng `test_diagram`
--
ALTER TABLE `test_diagram`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD CONSTRAINT `tbl_comments_ibfk_1` FOREIGN KEY (`id_topic`) REFERENCES `tbl_topic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `tbl_likes`
--
ALTER TABLE `tbl_likes`
  ADD CONSTRAINT `tbl_likes_ibfk_1` FOREIGN KEY (`id_topic`) REFERENCES `tbl_topic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
